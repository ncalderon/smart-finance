package com.calderon.sf.web.data.repository;

import com.calderon.sf.web.data.dto.BankEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface BankRepository extends CrudRepository<BankEntity, Integer> {
    List<BankEntity> findByName(String name);
}
