package com.calderon.sf.web.data.repository;

import com.calderon.sf.web.data.dto.AccountEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface AccountRepository extends CrudRepository<AccountEntity, Integer> {
    /*@Query("select new com.calderon.sf.web.data.dto.AccountEntity(id) " +
            " from AccountEntity a where accName = ?"
    )*/
    List<AccountEntity> findByAccName (String accName);
}
