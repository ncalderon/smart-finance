package com.calderon.sf.web.data.service;

import com.calderon.sf.web.data.dto.AccountEntity;
import com.calderon.sf.web.data.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

public class AccountServiceImpl implements AccountService {

    private AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    /*@Autowired
    public void setAccountRepository(AccountRepository repository) {
        System.out.println("We are using Setter Injection");
        this.accountRepository = repository;
    }*/

    @Override
    public List<AccountEntity> findByAccName(String accName) {
        return accountRepository.findByAccName(accName);
    }
}
