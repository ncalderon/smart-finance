package com.calderon.sf.web.data.service;

import com.calderon.sf.web.data.dto.AccountEntity;

import java.util.List;

public interface AccountService {
    List<AccountEntity> findByAccName (String accName);
}
